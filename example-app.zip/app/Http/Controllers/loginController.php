<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class loginController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');

        if ($username == "admin" && $password == "admin") {
            return redirect('home');
        } else {
            return redirect('login');
        }
    }
}
